# Imports here
import numpy as np
import matplotlib.pyplot as plt
import json
import torch
from torch import nn
from torchvision import datasets, transforms, models
from collections import OrderedDict
from PIL import Image
from workspace_utils import active_session

import seaborn as sb

data_dir = 'flowers2'
train_dir = data_dir + '/train'
valid_dir = data_dir + '/valid'
test_dir = data_dir + '/test'


# TODO: Define your transforms for the training, validation, and testing sets
def load_data():

    # data_dir = 'flowers2'
    # train_dir = data_dir + '/train'
    # valid_dir = data_dir + '/valid'
    # test_dir = data_dir + '/test'

    test_transforms = transforms.Compose([transforms.Resize(225),
                                          transforms.CenterCrop(224),
                                          transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    train_transforms = transforms.Compose([transforms.RandomResizedCrop(224),
                                           transforms.RandomRotation(45),
                                           transforms.RandomHorizontalFlip(),
                                           transforms.ToTensor(),
                                           transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    valid_transforms = transforms.Compose([transforms.Resize(225),
                                           transforms.CenterCrop(224),
                                           transforms.ToTensor(),
                                           transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    # TODO: Load the datasets with ImageFolder
    training_dataset = datasets.ImageFolder(train_dir, transform=train_transforms)
    valid_dataset = datasets.ImageFolder(valid_dir, transform=valid_transforms)
    test_dataset = datasets.ImageFolder(test_dir, transform=test_transforms)

    # TODO: Using the image datasets and the transforms, define the dataloaders

    train_loader = torch.utils.data.DataLoader(training_dataset, batch_size=64, shuffle=True)
    valid_loader = torch.utils.data.DataLoader(valid_dataset, batch_size=32)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=32)

    return train_loader, test_loader, valid_loader, training_dataset, test_dataset, valid_dataset


with open('cat_to_name.json', 'r') as f:
    cat_to_name = json.load(f)

print(cat_to_name)

print("Length = {}".format(len(cat_to_name)))

model = models.vgg16(pretrained=True)


def build_classifier(input_units, hidden_units, dropout):
    for param in model.parameters():
        param.requires_grad = False

    # classifier = nn.Sequential(OrderedDict([('fc1', nn.Linear(25088, 4096, bias=True)),
    #                                         ('relu', nn.ReLU()),
    #                                         ('dropout', nn.Dropout(p=0.5)),
    #                                         ('fc2', nn.Linear(4096, 102, bias=True)),
    #                                         ('output', nn.LogSoftmax(dim=1))]))
    classifier = nn.Sequential(OrderedDict([('fc1', nn.Linear(input_units, hidden_units, bias=True)),
                                            ('relu', nn.ReLU()),
                                            ('dropout', nn.Dropout(p=dropout)),
                                            ('fc2', nn.Linear(hidden_units, 102, bias=True)),
                                            ('output', nn.LogSoftmax(dim=1))]))
    model.classifier = classifier
    print(model.classifier)


# Loss function & gradient descent
# criterion = nn.NLLLoss()
# optimizer = optim.Adam(model.classifier.parameters(), lr=0.001)


# validate pass
def validation(validate_loader, criterion):
    loss = 0
    accurancy = 0

    for images, label in iter(validate_loader):
        images = images.cpu()
        label = label.cpu()

        output = model.forward(images)

        loss += criterion(output, label).item()

        propabilities = torch.exp(output)

        equality = (label.data == propabilities.max(dim=1)[1])

        accurancy += equality.type(torch.FloatTensor).mean()

        return loss, accurancy


def train_classisfier( epochs, train_loader, valid_loader, criterion, optimizer):
    with active_session():
        steps = 0
        print_every = 40

        for e in range(epochs):

            running_loss = 0

            for ii, (images, labels) in enumerate(train_loader):
                steps += 1

                optimizer.zero_grad()

                print(type(images))
                print(type(labels))

                output = model.forward(images)
                loss = criterion(output, labels)
                loss.backward()
                optimizer.step()

                running_loss += loss.item()

                if steps % print_every == 0:
                    model.eval()

                    with torch.no_grad():
                        validation_loss, accurancy = validation(valid_loader)

                    print("epochs: {}/{}".format(e + 1, epochs),
                          "Training loss: {:.3f}..".format(running_loss / print_every),
                          "Validation Loss: {:.3f}.. ".format(validation_loss / len(valid_loader)),
                          "Validation Accurancy: {:.3f}.. ".format(accurancy / len(valid_loader)))

                    running_loss = 0
                    model.train()
    return model, optimizer


def test_accurancy( test_loader):
    model.eval()
    model.cpu()

    with torch.no_grad():
        accurancy = 0
        for images, labels in iter(test_loader):
            images = images.cpu()
            labels = labels.cpu()
            output = model.forward(images)
            probabilities = torch.exp(output)
            equality = (labels.data == probabilities.max(dim=1)[1])
            accurancy += equality.type(torch.FloatTensor).mean()

        print("test accurancy: {}".format(accurancy / len(test_loader)))


def save_checkpoint(train_data):
    model.class_to_idx = train_data.class_to_idx
    checkpoint = {'architecture': 'vgg16',
                  'model_classifier': model.classifier,
                  'class_to_idx': model.class_to_idx,
                  'model_state_dict': model.state_dict()}
    torch.save(checkpoint, 'checkpoint.pth')


def load_checkpoint(save_dir):
    checkpoint = torch.load("checkpoint.pth", map_location=torch.device('cpu'))
    model1 = models.vgg16(pretrained=True)
    model1.class_to_idx = checkpoint['class_to_idx']
    model1.classifier = checkpoint['model_classifier']
    model1.load_state_dict(checkpoint['model_state_dict'])

    return model1


def process_image(image):
    # process PIL in  Pytorch model
    pil_image = Image.open(image)

    # Resize
    if pil_image.size[0] > pil_image.size[1]:
        pil_image.thumbnail((5000, 256))
    else:
        pil_image.thumbnail((256, 5000))

    # Crop
    left_margin = (pil_image.width - 224) / 2
    bottom_margin = (pil_image.height - 224) / 2
    right_margin = left_margin + 224
    top_margin = bottom_margin + 224

    pil_image = pil_image.crop((left_margin, bottom_margin, right_margin, top_margin))

    # normalize
    np_image = np.array(pil_image) / 225
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    np_image = (np_image - mean) / std

    np_image = np_image.transpose((2, 0, 1))
    return np_image


def imshow(image_show, ax=None, title=None):
    if ax is None:
        ax = plt.subplot()

    image_show = image_show.transpose((1, 2, 0))

    mean = np.array([0.485, 0.456, 0.4066])
    std = np.array([0.229, 0.224, 0.225])
    image_show = std * image_show + mean

    if title is not None:
        ax.set_title(title)

    image_show = np.clip(image_show, 0, 0)

    ax.imshow(image_show)

    return ax


# image = process_image('flowers/test/1/image_06743.jpg')
# imshow(image)

def predict(image_path, top_k=5):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''

    # TODO: Implement the code to predict the class from an image file

    # removed the model in cpu no need to GPU on this part (to avoid wights issues)
    model.to("cpu")
    model.eval()
    # Convert image to torch objects
    torch_image = torch.from_numpy(np.expand_dims(process_image(image_path), axis=0)).type(torch.FloatTensor).to("cpu")
    # Find probabilities and scale it
    log_probs = model.forward(torch_image)
    linear_probs = torch.exp(log_probs)

    # Find the top_k
    top_probs, top_labels = linear_probs.topk(top_k)

    # Detatch all of the details
    top_probs = np.array(top_probs.detach())[0]
    top_labels = np.array(top_labels.detach())[0]

    print("class_to_idx", model.class_to_idx.items())
    for lab in top_labels:
        print("top_labels", lab)

    # Convert to classes
    idx_to_class = {val: key for key, val in model.class_to_idx.items()}
    print("idx_to_class", idx_to_class)

    top_labels = [idx_to_class[lab] for lab in top_labels]

    top_flowers = [cat_to_name[lab] for lab in top_labels]

    return top_probs, top_labels, top_flowers

#
# # TODO: Display an image along with the top 5 classes
# # Inputs: paths to saved model and test image
# model_path = 'checkpoint.pth'
# image_path = 'flowers/test/15/image_06351.jpg'
#
# # Getting prediction
# probs = predict(image_path, model_path, topk=5)
# classes = predict(image_path, model_path, topk=5)
#
# # Converting classes to names
# flower_names = []
# for i in classes:
#     flower_names += [cat_to_name[i]]
#
# # Creating PIL image
# image = Image.open(image_path)
#
# # Plotting test image and predicted probabilites
# f, ax = plt.subplots(2, figsize=(6, 10))
#
# ax[0].imshow(image)
# ax[0].set_title(flower_names[0])
#
# y_names = np.arange(len(flower_names))
# ax[1].barh(y_names, probs, color=sb.color_palette()[0])
# ax[1].set_yticks(y_names)
# ax[1].set_yticklabels(flower_names)
# ax[1].invert_yaxis()
#
# plt.show()

import ssl
import argparse
from torchvision import models
from torch import nn
from torch import optim

from ImageClassifier import train_classisfier, test_accurancy, save_checkpoint, load_data, load_checkpoint, \
    build_classifier

ssl._create_default_https_context = ssl._create_unverified_context

parser = argparse.ArgumentParser(description="Training network")

# parser.add_argument('data_directory', action='store', default='flowers2',
#                     help='Enter path to training data.')

parser.add_argument('--arch', action='store',
                    dest='pretrained_model', default='vgg16',
                    help='Enter pretrained model to use; this classifier can currently work with\
                           VGG and Densenet architectures. The default is VGG-16.')

parser.add_argument('--save_dir', action='store',
                    dest='save_directory', default='checkpoint.pth',
                    help='Enter location to save checkpoint in.')

parser.add_argument('--learning_rate', action='store',
                    dest='lr', type=int, default=0.001,
                    help='Enter learning rate for training the model, default is 0.001.')

parser.add_argument('--dropout', action='store',
                    dest='drpt', type=int, default=0.05,
                    help='Enter dropout for training the model, default is 0.05.')

parser.add_argument('--hidden_units', action='store',
                    dest='units', type=int, default=500,
                    help='Enter number of hidden units in classifier, default is 500.')

parser.add_argument('--epochs', action='store',
                    dest='num_epochs', type=int, default=5,
                    help='Enter number of epochs to use during training.')

results = parser.parse_args()

# data_dir = results.data_directory
save_dir = results.save_directory
learning_rate = results.lr
dropout = results.drpt
hidden_units = results.units
epochs = results.num_epochs

# Load and prepare data
train_loader, test_loader, valid_loader, train_data, test_data, valid_data = load_data()

prepare_model = results.pretrained_model
model = getattr(models, prepare_model)(pretrained=True)

# build new clasifier
input_units = model.classifier[0].in_features
build_classifier(input_units, hidden_units, dropout)

criterion = nn.NLLLoss()
optimizer = optim.Adam(model.classifier.parameters(), lr=learning_rate)

# train_classisfier
model = train_classisfier(epochs, train_loader, valid_loader, criterion, optimizer)
optimizer = train_classisfier(epochs, train_loader, valid_loader, criterion, optimizer)

# Test accurancy
test_accurancy(test_loader)
# Save checkpoint
save_checkpoint(train_data)
# Load model
loaded_model = load_checkpoint(save_dir)
